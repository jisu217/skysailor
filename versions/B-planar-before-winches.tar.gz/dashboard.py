"""Headless MuJoCo trajectories served to a browser-native 3D viewer."""
from pathlib import Path
from threading import BoundedSemaphore
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
import mujoco
import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from clover import CloverSim, Config
from leaf import SEGMENTS
from dome import DomeSim
from b_control import BController


class Experiment(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)
    height: float = Field(3, ge=0.5, le=10)
    tilt: float = Field(15, ge=0, le=80)
    wind_x: float = Field(0, ge=-3, le=3)
    wind_y: float = Field(0, ge=-3, le=3)
    kp: float = Field(0.018, ge=0, le=0.08)
    kd: float = Field(0.004, ge=0, le=0.02)
    seed: int = Field(0, ge=0, le=9999)
    seconds: float = Field(5, ge=0.1, le=10)
    mode: Literal['compare', 'pd', 'off'] = 'compare'
    variant: Literal['A','B'] = 'A'
    b_controller: Literal['manual','p','pd','aero_pd','predictive'] = 'manual'
    line_length_mm: float = Field(float(np.hypot(.12,.12)*1000), ge=130, le=400)
    drive_speed_mm_s: float = Field(40, ge=5, le=300)
    target_x_mm: float = Field(0, ge=-120, le=120)
    target_y_mm: float = Field(0, ge=-120, le=120)
    air_density: float = Field(1.225, ge=0, le=2)


app = FastAPI(title='Clover Flight Lab')
slots = BoundedSemaphore(2)


def geometry(sim):
    result = []
    for i in range(1, sim.model.ngeom):
        g = {'type':int(sim.model.geom_type[i]), 'size':sim.model.geom_size[i].tolist(), 'color':sim.model.geom_rgba[i].tolist()}
        if 1 < i < sim.model.ngeom-1:
            j = i-2 if isinstance(sim,DomeSim) else (i-2) % SEGMENTS
            if isinstance(sim,DomeSim):g['triangles'] = sim.panels[j]['vertices'].tolist()
            else:g['polygon'] = sim.panels[j]['polygon'].tolist()
            g['area'] = sim.panels[j]['area']
        result.append(g)
    return result


def snapshot(sim):
    data = sim.data
    rot_vel = np.zeros(6)
    mujoco.mj_objectVelocity(sim.model, data, mujoco.mjtObj.mjOBJ_BODY, sim.hub, rot_vel, 0)
    aero = sim.aerodynamics()
    body_ids = sim.model.geom_bodyid[1:]
    quats = []
    for matrix in data.xmat[body_ids]:
        quat = np.empty(4)
        mujoco.mju_mat2Quat(quat, matrix)
        quats.append(quat.tolist())
    return {
        't': round(float(data.time), 6),
        'height': float(data.xpos[sim.hub, 2]),
        'tilt': float(sim.record()[2]),
        'speed': float(-rot_vel[5]),
        'spool': (sim.spool*1000).tolist(),
        'tension': None if isinstance(sim,DomeSim) else sim.tensions.tolist(),
        'position': data.xpos[body_ids].tolist(),
        'quaternion': quats,
        'tips': data.site_xpos[sim.tips].tolist(),
        'anchor': data.site_xpos[sim.anchor].tolist(),
        'center': data.xpos[sim.hub].tolist(),
        'aero_position': data.site_xpos[sim.air_sites].tolist(),
        'aero_force': aero['force'].tolist(),
        'airflow': (aero['airflow'] if sim.c.air_density > 0 else np.zeros_like(aero['airflow'])).tolist(),
        'air_present': sim.c.air_density > 0,
        'loading': aero['loading'].tolist(),
        'aero_total': aero['force'].sum(axis=0).tolist(),
        'gravity': (sim.model.body_mass.sum()*sim.model.opt.gravity).tolist(),
        'com': data.subtree_com[sim.hub].tolist(),
        'target_com': sim.target_com_world().tolist() if isinstance(sim,DomeSim) else None,
        'hang': sim.hang if isinstance(sim,DomeSim) else None,
        'target_xy': sim.active_target_xy.tolist() if isinstance(sim,DomeSim) else None,
        'payload_local': (data.xmat[sim.hub].reshape(3,3).T@(data.xpos[sim.payload]-data.xpos[sim.hub])).tolist() if isinstance(sim,DomeSim) else None,
        'system_com': (np.sum(sim.model.body_mass[:,None]*data.xipos,axis=0)/sim.model.body_mass.sum()).tolist(),
    }


def make_sim(params):
    config=Config(height=params.height,kp=params.kp,kd=params.kd,air_density=params.air_density)
    if params.variant == 'B':
        config.spool_speed=params.drive_speed_mm_s/1000
        return DomeSim(config,target_xy=np.array([params.target_x_mm,params.target_y_mm])/1000,line_length=params.line_length_mm/1000)
    return CloverSim(config)


def experiment(params):
    config = Config(height=params.height, kp=params.kp, kd=params.kd, air_density=params.air_density)
    result = {'parameters':params.model_dump(), 'runs':{}, 'geometry':None}
    for mode in (['off','pd'] if params.mode == 'compare' else [params.mode]):
        sim = make_sim(params)
        sim.reset(params.tilt, params.seed)
        if sim.landed():raise ValueError("줄 길이에 비해 시작 높이가 낮습니다. 낙하 높이를 높여주세요.")
        sim.wind = np.array([params.wind_x, params.wind_y, 0.])
        if result['geometry'] is None:
            result['geometry'] = geometry(sim)
        controller=BController(params.b_controller if mode=='pd' else 'center') if isinstance(sim,DomeSim) else None
        if controller:controller.action(sim)
        frames = [snapshot(sim)]
        tilts = [float(sim.record()[2])]
        count = 0
        initial_com_height=float(sim.data.subtree_com[sim.hub,2])
        while sim.data.time < params.seconds-1e-9 and not sim.landed():
            action=controller.action(sim) if controller else (sim.pd_action() if mode=='pd' else np.zeros_like(sim.spool))
            sim.step(action, [params.wind_x,params.wind_y,0])
            tilts.append(float(sim.record()[2]))
            count += 1
            if count%10 == 0:
                frames.append(snapshot(sim))
        if abs(frames[-1]['t']-sim.data.time) > 1e-8:
            frames.append(snapshot(sim))
        result['runs'][mode] = {
            'frames':frames,
            'summary':{'duration':float(sim.data.time), 'mean_descent_speed':float((initial_com_height-sim.data.subtree_com[sim.hub,2])/sim.data.time), 'rms_tilt':float(np.sqrt(np.mean(np.square(tilts)))), 'max_tilt':max(tilts), 'inverted':bool(max(tilts)>90), 'termination':'ground' if sim.landed() else 'timeout'},
        }
    return result


@app.get('/api/health')
def health():
    return {'status':'ok','engine':'MuJoCo','version':mujoco.__version__}


@app.post('/api/simulate')
def simulate(params: Experiment):
    if not slots.acquire(blocking=False):
        raise HTTPException(503, '다른 실험을 계산 중입니다. 잠시 후 다시 실행해주세요.')
    try:
        return experiment(params)
    except ValueError as error:
        raise HTTPException(422,str(error)) from error
    finally:
        slots.release()


@app.get('/api/initial')
def initial(variant: Literal['A','B']='A'):
    sim = make_sim(Experiment(variant=variant))
    return {'frame':snapshot(sim), 'geometry':geometry(sim)}


static = Path(__file__).parent/'web'/'dist'
if static.exists():
    app.mount('/', StaticFiles(directory=static, html=True), name='dashboard')
