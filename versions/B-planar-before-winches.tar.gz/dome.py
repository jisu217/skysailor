"""B: rigid shallow spherical cap with an ideal planar movable payload (three lines are visual guides).

Panel drag is an uncalibrated quasi-steady surrogate, NOT a CFD pressure field.
"""
import numpy as np
import mujoco
from clover import CloverSim, Config

RADIUS = .12
CAP_HEIGHT = .04
SPHERE_RADIUS = (RADIUS**2+CAP_HEIGHT**2)/(2*CAP_HEIGHT)
MU_MIN = 1-CAP_HEIGHT/SPHERE_RADIUS
DOME_MASS = .0042
PAYLOAD_MASS = .004
HANG = .12


def patches():
    result = []
    def point(mu, phi):
        return SPHERE_RADIUS*np.array([np.sqrt(max(0,1-mu*mu))*np.cos(phi),np.sqrt(max(0,1-mu*mu))*np.sin(phi),mu])+[0,0,CAP_HEIGHT-SPHERE_RADIUS]
    for band in range(3):
        for sector in range(8):
            mus = np.linspace(MU_MIN+(1-MU_MIN)*band/3,MU_MIN+(1-MU_MIN)*(band+1)/3,5)
            phis = np.linspace(sector*np.pi/4,(sector+1)*np.pi/4,5)
            triangles = []
            for a,b in zip(mus[:-1],mus[1:]):
                for c,d in zip(phis[:-1],phis[1:]):
                    v0,v1,v2,v3 = point(a,c),point(a,d),point(b,d),point(b,c)
                    for triangle in ([v0,v1,v2],[v0,v2,v3]):
                        if np.linalg.norm(np.cross(triangle[1]-triangle[0],triangle[2]-triangle[0])) > 1e-12:
                            triangles.extend(triangle)
            center = point(MU_MIN+(1-MU_MIN)*(band+.5)/3,(sector+.5)*np.pi/4)
            normal = (center-[0,0,CAP_HEIGHT-SPHERE_RADIUS])/SPHERE_RADIUS
            result.append({'vertices':np.array(triangles),'normal':normal,'center':center,'area':2*np.pi*SPHERE_RADIUS*CAP_HEIGHT/24})
    return result


def model_xml(config, surface, attachments, hang=HANG):
    assets,geoms,sites = [],[],[]
    for i,p in enumerate(surface):
        # Non-coplanar curved patch vertices produce a valid native visual mesh.
        values=' '.join(str(x) for x in p['vertices'].ravel())
        assets.append(f'<mesh name="patch{i}" vertex="{values}"/>')
        geoms.append(f'<geom type="mesh" mesh="patch{i}" rgba="0.3 0.7 0.6 1"/>')
        pos=' '.join(str(x) for x in p['center']);normal=' '.join(str(x) for x in p['normal'])
        sites.append(f'<site name="air{i}" pos="{pos}" zaxis="{normal}"/>')
    for i,p in enumerate(attachments):
        sites.append(f'<site name="tip{i}" pos="'+ ' '.join(str(x) for x in p)+'"/>')
    mean_mu2=(1+MU_MIN+MU_MIN**2)/3
    mean_x2=SPHERE_RADIUS**2*(1-mean_mu2)/2
    var_z=CAP_HEIGHT**2/12
    inertia_xy=DOME_MASS*(mean_x2+var_z)
    inertia_z=2*DOME_MASS*mean_x2
    cables=''.join(f'<spatial name="line{i}" width=".0006"><site site="tip{i}"/><site site="anchor"/></spatial>' for i in range(3))
    return f'''<mujoco model="dome_b"><asset>{''.join(assets)}</asset>
      <option timestep="{config.dt}" integrator="implicitfast" gravity="0 0 -9.81"/>
      <default><geom contype="0" conaffinity="0"/><site size=".001"/></default>
      <worldbody><geom type="plane" size="5 5 .1"/>
        <body name="hub" pos="0 0 {config.height}"><freejoint/>
          <inertial pos="0 0 {CAP_HEIGHT/2}" mass="{DOME_MASS}" diaginertia="{inertia_xy} {inertia_xy} {inertia_z}"/>
          <geom type="sphere" size=".004"/>{''.join(geoms)}{''.join(sites)}
          <body name="payload" pos="0 0 {-hang}">
            <joint name="move_x" type="slide" axis="1 0 0" damping=".03"/>
            <joint name="move_y" type="slide" axis="0 1 0" damping=".03"/>
            <geom type="box" size=".012 .01 .007" mass="{PAYLOAD_MASS}"/><site name="anchor"/>
          </body>
        </body>
      </worldbody><tendon>{cables}</tendon>
      <actuator><position joint="move_x" kp="30" kv=".5" forcerange="-.08 .08"/>
      <position joint="move_y" kp="30" kv=".5" forcerange="-.08 .08"/></actuator></mujoco>'''


class DomeSim(CloverSim):
    def __init__(self, config=None, target_xy=(0,0), line_length=None):
        self.c = config or Config()
        self.line_length = float(line_length) if line_length is not None else float(np.hypot(RADIUS,HANG))
        if not np.isfinite(self.line_length) or not RADIUS < self.line_length <= .5:
            raise ValueError("기본 줄 길이는 120 mm보다 크고 500 mm 이하여야 합니다.")
        self.hang=float(np.sqrt(self.line_length**2-RADIUS**2))
        if not np.isfinite(self.c.spool_speed) or self.c.spool_speed <= 0:
            raise ValueError("구동 속도는 양수여야 합니다.")
        self.panels = patches()
        self.attachments = np.array([[RADIUS*np.cos(i*2*np.pi/3),RADIUS*np.sin(i*2*np.pi/3),0] for i in range(3)])
        self.target_xy = np.asarray(target_xy,dtype=float)
        if self.target_xy.shape != (2,) or not np.all(np.isfinite(self.target_xy)):
            raise ValueError('목표 위치는 유한한 X/Y 값이어야 합니다.')
        self.validate_target(self.target_xy)
        self.target_payload = np.r_[self.target_xy,-self.hang]
        self.model = mujoco.MjModel.from_xml_string(model_xml(self.c,self.panels,self.attachments,self.hang))
        self.data = mujoco.MjData(self.model)
        self.hub = self.model.body('hub').id
        self.payload = self.model.body('payload').id
        self.air_sites = [self.model.site(f'air{i}').id for i in range(24)]
        self.tips = [self.model.site(f'tip{i}').id for i in range(3)]
        self.anchor = self.model.site('anchor').id
        self.reset()

    def validate_target(self, xy):
        bary=np.linalg.solve(np.vstack([self.attachments[:,:2].T,np.ones(3)]),np.r_[xy,1.])
        if np.any(bary < -1e-8):
            raise ValueError('목표 위치를 삼각형 안에 지정해주세요.')

    def reset(self, tilt_deg=15, seed=0):
        mujoco.mj_resetData(self.model,self.data)
        self.wind=np.zeros(3)
        angle=np.random.default_rng(seed).uniform(-np.pi,np.pi)
        quat=np.r_[np.cos(np.deg2rad(tilt_deg)/2),np.array([np.cos(angle),np.sin(angle),0])*np.sin(np.deg2rad(tilt_deg)/2)]
        self.data.qpos[3:7]=quat
        self.active_target_xy=self.target_xy.copy()
        self.spool=np.zeros(2)  # Compatibility: commanded planar position, not a spool.
        self.tensions=np.zeros(3)  # Guides have no physical tension in this abstraction.
        mujoco.mj_forward(self.model,self.data)
        return self.observe()

    def pd_action(self):
        # Compatibility name: B is target tracking, NOT the A attitude PD law.
        return self.target_xy/RADIUS

    def step(self, action, wind=(0,0,0)):
        action=np.asarray(action,dtype=float)
        if action.shape != (2,) or not np.all(np.isfinite(action)):
            raise ValueError('B action must contain two finite numbers')
        target=action*RADIUS
        self.validate_target(target)
        delta=target-self.spool
        distance=np.linalg.norm(delta)
        self.spool+=delta*min(1.,self.c.spool_speed*self.c.dt/max(distance,1e-12))
        self.data.ctrl[:]=self.spool
        self.data.qfrc_applied[:]=0
        self.wind=np.asarray(wind,dtype=float)
        for sid,force in zip(self.air_sites,self.aerodynamics()['force']):self.force(sid,force)
        mujoco.mj_step(self.model,self.data);mujoco.mj_forward(self.model,self.data)
        if not np.all(np.isfinite(self.data.qpos)):raise FloatingPointError('non-finite B state')
        return self.observe()

    def aerodynamics(self):
        forces,airflow,loading=[],[],[]
        for sid,p in zip(self.air_sites,self.panels):
            normal=self.data.site_xmat[sid].reshape(3,3)[:,2]
            relative=self.velocity(sid)-self.wind
            vn=np.dot(relative,normal);tangent=relative-vn*normal
            load=.5*self.c.air_density*self.c.drag_normal*vn*abs(vn)
            force=-p['area']*(load*normal+.5*self.c.air_density*self.c.drag_tangent*np.linalg.norm(tangent)*tangent)
            forces.append(force);airflow.append(-relative);loading.append(abs(load))
        return {'force':np.array(forces),'airflow':np.array(airflow),'loading':np.array(loading)}

    def target_com_world(self):
        local=(DOME_MASS*np.array([0,0,CAP_HEIGHT/2])+PAYLOAD_MASS*np.r_[self.active_target_xy,-self.hang])/(DOME_MASS+PAYLOAD_MASS)
        return self.data.xpos[self.hub]+self.data.xmat[self.hub].reshape(3,3)@local
