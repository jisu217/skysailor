import numpy as np
import pytest
from dome import DomeSim, HANG, RADIUS, DOME_MASS, PAYLOAD_MASS
from clover import Config
from dashboard import Experiment, experiment, app
from fastapi.testclient import TestClient


def com(sim):
    return np.sum(sim.model.body_mass[:,None]*sim.data.xipos,axis=0)/sim.model.body_mass.sum()


def test_b_internal_motion_preserves_com_ballistics_and_height():
    sim=DomeSim(Config(air_density=0),target_xy=(.025,.01))
    sim.reset(0)
    before=com(sim)
    previous=sim.spool.copy()
    for _ in range(300):
        sim.step(sim.pd_action())
        assert np.linalg.norm(sim.spool-previous) <= .04*sim.c.dt+1e-12
        previous=sim.spool.copy()
    assert np.linalg.norm((com(sim)-before)[:2]) < 1e-5
    assert com(sim)[2]-before[2] == pytest.approx(-.5*9.81*sim.data.time**2,abs=.002)
    local=sim.data.xmat[sim.hub].reshape(3,3).T@(sim.data.xpos[sim.payload]-sim.data.xpos[sim.hub])
    assert local[2] == pytest.approx(-HANG,abs=1e-10)
    assert np.linalg.norm(local[:2]) > .005


def test_b_triangle_validation_and_target_com():
    with pytest.raises(ValueError):DomeSim(target_xy=(-.09,0))
    sim=DomeSim(target_xy=(.03,.01))
    sim.reset(0)
    target=sim.target_com_world()-sim.data.xpos[sim.hub]
    assert target[:2] == pytest.approx(np.array([.03,.01])*PAYLOAD_MASS/(DOME_MASS+PAYLOAD_MASS))
    assert sim.model.nv == 8  # one free dome + two internal slide coordinates
    assert len(sim.tips) == 3
    assert np.linalg.norm(sim.attachments[0]-sim.attachments[1]) == pytest.approx(np.sqrt(3)*RADIUS)


def test_b_api_and_a_remain_separate():
    client=TestClient(app)
    a=client.get('/api/initial?variant=A').json()
    b=client.get('/api/initial?variant=B').json()
    assert len(a['frame']['tips']) == 4
    assert len(b['frame']['tips']) == 3
    assert 'polygon' in a['geometry'][1]
    assert 'triangles' in b['geometry'][1]
    assert b['frame']['tension'] is None
    assert b['frame']['payload_local'][2] == pytest.approx(-.12)
    assert client.post('/api/simulate',json={'variant':'B','target_x_mm':-100}).status_code == 422
    result=experiment(Experiment(variant='B',target_x_mm=20,seconds=.25))
    assert result['runs']['pd']['frames'][-1]['payload_local'][0] > .005
    assert abs(result['runs']['off']['frames'][-1]['payload_local'][0]) < .003


def test_b_feedback_holds_small_tilt_and_slows_descent():
    result=experiment(Experiment(variant='B',b_controller='aero_pd',tilt=5,seed=11))
    controlled=result['runs']['pd'];baseline=result['runs']['off']
    assert controlled['summary']['max_tilt'] < 6
    assert controlled['summary']['rms_tilt'] < 3
    assert controlled['summary']['duration'] > 1.4*baseline['summary']['duration']
    assert controlled['summary']['mean_descent_speed'] < baseline['summary']['mean_descent_speed']
    targets=np.array([f['target_xy'] for f in controlled['frames']])
    assert np.ptp(targets[:,0])+np.ptp(targets[:,1]) > .005
    for frame in baseline['frames']:assert frame['target_xy'] == [0,0]
    sim=DomeSim()
    for target in targets:sim.validate_target(target)
    commands=np.array([f['spool'] for f in controlled['frames']])/1000
    times=np.array([f['t'] for f in controlled['frames']])
    assert np.all(np.linalg.norm(np.diff(commands,axis=0),axis=1) <= .04*np.diff(times)+1e-10)


def test_b_controller_projection_and_feedback_update():
    from b_control import BController,project_triangle
    sim=DomeSim();sim.reset(15,2)
    controller=BController('aero_pd')
    first=controller.action(sim)
    for _ in range(19):sim.step(controller.action(sim))
    assert controller.action(sim) == pytest.approx(first)  # 50 Hz sample-and-hold
    sim.step(controller.action(sim))
    controller.action(sim)
    assert controller.next_update == pytest.approx(.04)
    projected=project_triangle(np.array([-1.,0]),sim.attachments[:,:2])
    assert projected == pytest.approx([-.06,0])
    sim.validate_target(projected)
    with pytest.raises(ValueError):project_triangle([np.nan,0],sim.attachments[:,:2])
    with pytest.raises(ValueError):BController('unknown')


def test_b_length_updates_geometry_com_and_controller():
    from b_control import BController
    sim=DomeSim(line_length=.25)
    sim.reset(0)
    hang=np.sqrt(.25**2-.12**2)
    assert sim.hang == pytest.approx(hang)
    assert sim.data.xpos[sim.payload,2]-sim.data.xpos[sim.hub,2] == pytest.approx(-hang)
    assert np.linalg.norm(sim.data.site_xpos[sim.tips]-sim.data.site_xpos[sim.anchor],axis=1) == pytest.approx([.25]*3)
    expected=(DOME_MASS*.02-PAYLOAD_MASS*hang)/(DOME_MASS+PAYLOAD_MASS)
    assert sim.target_com_world()[2]-sim.data.xpos[sim.hub,2] == pytest.approx(expected)
    sim.reset(5)
    ctrl=BController('aero_pd')
    for _ in range(200):sim.step(ctrl.action(sim))
    assert np.all(np.isfinite(sim.data.qpos))


def test_b_api_speed_is_applied_to_both_runs_and_invalid_settings_rejected():
    outputs=[]
    for speed in [10,100]:
        result=experiment(Experiment(variant='B',line_length_mm=250,drive_speed_mm_s=speed,target_x_mm=30,seconds=.1))
        outputs.append(result['runs']['pd']['frames'][-1]['spool'][0])
        for run in result['runs'].values():
            assert run['frames'][0]['hang'] == pytest.approx(np.sqrt(.25**2-.12**2))
            assert run['frames'][0]['payload_local'][2] == pytest.approx(-np.sqrt(.25**2-.12**2))
    assert outputs == pytest.approx([1,10])
    client=TestClient(app)
    for invalid in [{'line_length_mm':120},{'drive_speed_mm_s':0},{'line_length_mm':401}]:
        assert client.post('/api/simulate',json={'variant':'B',**invalid}).status_code == 422


def test_b_prediction_does_not_advance_live_state_and_respects_domain():
    from b_control import BController
    sim=DomeSim(Config(spool_speed=.1),line_length=.25)
    sim.reset(15)
    before=sim.data.qpos.copy();before_velocity=sim.data.qvel.copy()
    ctrl=BController('predictive')
    target=ctrl.action(sim)*RADIUS
    assert sim.data.time == 0
    assert sim.c.dt == .001
    assert sim.data.qpos == pytest.approx(before)
    assert sim.data.qvel == pytest.approx(before_velocity)
    assert sim.spool == pytest.approx([0,0])
    sim.validate_target(target)
    assert ctrl.predictor.hang == pytest.approx(sim.hang)
    assert ctrl.predictor.c.spool_speed == .1
