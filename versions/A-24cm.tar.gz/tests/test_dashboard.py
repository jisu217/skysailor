import numpy as np
from fastapi.testclient import TestClient
from dashboard import app, Experiment, experiment, slots
from clover import run

client = TestClient(app)


def test_health_and_initial_geometry():
    assert client.get('/api/health').json()['status'] == 'ok'
    data = client.get('/api/initial').json()
    assert len(data['geometry']) == len(data['frame']['position']) == 26
    assert len(data['frame']['tips']) == 4
    assert data['frame']['height'] == 3


def test_dashboard_trajectory_matches_original_engine():
    result = experiment(Experiment())
    for mode in ('pd','off'):
        trajectory = run(mode=mode)
        actual = result['runs'][mode]
        assert abs(actual['summary']['duration']-trajectory[-1,0]) < 1e-9
        assert abs(actual['summary']['rms_tilt']-np.sqrt(np.mean(trajectory[:,2]**2))) < 1e-9
        assert abs(actual['frames'][-1]['height']-trajectory[-1,1]) < 1e-9
        assert actual['frames'][0]['t'] == 0
        assert actual['summary']['termination'] == 'ground'


def test_invalid_and_busy_requests():
    assert client.post('/api/simulate',json={'height':-1}).status_code == 422
    assert client.post('/api/simulate',json={'kp':2}).status_code == 422
    assert client.post('/api/simulate',json={'unknown':1}).status_code == 422
    slots.acquire()
    slots.acquire()
    try:
        assert client.post('/api/simulate',json={}).status_code == 503
    finally:
        slots.release()
        slots.release()


def test_short_run_has_final_frame_and_timeout():
    response=client.post('/api/simulate',json={'seconds':.105,'mode':'pd'})
    assert response.status_code == 200
    data=response.json()['runs']['pd']
    assert data['frames'][-1]['t'] == .105
    assert data['summary']['termination'] == 'timeout'


def test_aero_visualization_uses_physics_and_vacuum():
    data = client.post('/api/simulate',json={'seconds':.1,'mode':'pd','air_density':0}).json()
    assert len(data['geometry']) == 26
    assert len([g for g in data['geometry'] if 'polygon' in g]) == 24
    frame = data['runs']['pd']['frames'][-1]
    assert len(frame['aero_force']) == 24
    assert np.allclose(frame['aero_total'],0)
    assert np.allclose(frame['loading'],0)
    assert np.allclose(frame['airflow'],0)
    assert frame['air_present'] is False
    assert np.allclose(frame['gravity'],[0,0,-.0082*9.81])
    assert frame['height'] < 3
